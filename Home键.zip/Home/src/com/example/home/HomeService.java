package com.example.home;

import com.example.home.ScreenListener.ScreenStateListener;


import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat;
import android.widget.RemoteViews;

public class HomeService extends Service implements ScreenStateListener{
    private ScreenListener listener;
	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return null;
	}
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
    	listener=new ScreenListener(HomeService.this);
    	listener.begin(this);
    	Intent i = new Intent(HomeService.this,MyActivity.class);
	
		i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		
		
		startActivity(i);
    	return START_STICKY;
    
    
    }
   
    @Override
    public void onDestroy() {
    	// TODO Auto-generated method stub
         listener.unregisterListener();
    	super.onDestroy();
    }
	@Override
	public void onScreenOn() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void onScreenOff() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void onUserPresent() {
	       
		Intent i = new Intent(Intent.ACTION_MAIN);
		i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); 
		i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		
		i.addCategory(Intent.CATEGORY_HOME);
		startActivity(i);
	}
    
}
