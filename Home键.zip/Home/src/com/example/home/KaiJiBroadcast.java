package com.example.home;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class KaiJiBroadcast extends BroadcastReceiver{

	@Override
	public void onReceive(Context arg0, Intent intent) {
		 if (intent.getAction().equals(Intent.ACTION_BOOT_COMPLETED)) {
		       
			 Intent intent2=new Intent(arg0,HomeService.class);
			 arg0.startService(intent2);
		 }
		
	}

}
